package com.ethem.catres;

import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Shizuku uzerinden kabuk (shell) komutu calistirir. */
public class Sh {

    static class Result {
        int code;
        String out;
    }

    static boolean alive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean ready() {
        try {
            return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static Result run(String cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess",
                String[].class, String[].class, String.class);
        m.setAccessible(true);
        Object[] args = new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null};
        Process p = (Process) m.invoke(null, args);
        StringBuilder sb = new StringBuilder();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = r.readLine()) != null) {
            sb.append(line).append('\n');
        }
        Result res = new Result();
        res.code = p.waitFor();
        res.out = sb.toString().trim();
        return res;
    }
}
