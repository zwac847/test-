package com.ethem.catres;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class ActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context ctx, Intent intent) {
        final String action = intent.getAction();
        final long token = intent.getLongExtra("t", 0);
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err;
                if ("KEEP".equals(action)) {
                    err = Ops.keep(ctx, token);
                } else {
                    err = Ops.reset(ctx);
                }
                final String msg = err != null ? err
                        : ("KEEP".equals(action) ? "Tamam, kalıyor" : "Sıfırlandı");
                android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                    }
                });
                pr.finish();
            }
        }).start();
    }
}
