package com.ethem.catres;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Guvenlik mantigi:
 * 1) Boyutu degistirmeden ONCE telefonun kabugunda (uygulamadan bagimsiz) 30 sn'lik
 *    bir geri alma sayaci baslatilir.
 * 2) Kullanici 30 sn icinde KALSIN'a basmazsa sayac boyutu kendisi eski haline dondurur.
 * 3) Sayac baslamazsa boyut hic degistirilmez.
 */
public class Ops {

    static final int SECONDS = 30;
    static final String DIR = "/data/local/tmp/";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("cat", Context.MODE_PRIVATE);
    }

    /** Basariliysa null, hata varsa hata metni doner. */
    static String apply(Context c, int w, int h) {
        try {
            if (!Sh.ready()) return "Shizuku hazır değil";
            long t = System.currentTimeMillis();
            String latest = DIR + "cr_latest";
            String ok = DIR + "cr_ok_" + t;
            String dead = "echo " + t + " > " + latest
                    + "; nohup sh -c 'sleep " + SECONDS
                    + "; if [ \"$(cat " + latest + ")\" = " + t + " ] && [ ! -f " + ok + " ]; then "
                    + "wm size reset; wm density reset; fi; rm -f " + ok + "' >/dev/null 2>&1 &";
            Sh.Result r = Sh.run(dead);
            if (r.code != 0) return "Geri alma sayacı başlamadı, boyut değiştirilmedi: " + r.out;

            r = Sh.run("wm size " + w + "x" + h);
            String low = r.out.toLowerCase();
            if (r.code != 0 || low.contains("error") || low.contains("exception")) {
                Sh.run("echo none > " + latest + "; wm size reset; wm density reset");
                return "Olmadı, geri alındı: " + r.out;
            }
            prefs(c).edit().putBoolean("active", true).putLong("token", t).apply();
            Notifs.show(c, t, true);
            return null;
        } catch (Throwable e) {
            return "Hata: " + e;
        }
    }

    static String keep(Context c, long token) {
        try {
            Sh.Result r = Sh.run("touch " + DIR + "cr_ok_" + token);
            if (r.code != 0) return "Onaylanamadı: " + r.out;
            Notifs.show(c, token, false);
            return null;
        } catch (Throwable e) {
            return "Hata: " + e;
        }
    }

    static String reset(Context c) {
        try {
            Sh.Result r = Sh.run("echo none > " + DIR + "cr_latest; wm size reset; wm density reset");
            if (r.code != 0) return "Sıfırlanamadı: " + r.out;
            prefs(c).edit().putBoolean("active", false).apply();
            Notifs.cancel(c);
            return null;
        } catch (Throwable e) {
            return "Hata: " + e;
        }
    }
}
