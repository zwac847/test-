package com.ethem.catres;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private SharedPreferences p;
    private TextView status, info, wTxt, hTxt;
    private SeekBar sw, sh;
    private LinearLayout gamesBox;
    private int pw = 0, ph = 0;
    private final ExecutorService ex = Executors.newSingleThreadExecutor();

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(8), 0, dp(4));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("cat", MODE_PRIVATE);
        pw = p.getInt("pw", 0);
        ph = p.getInt("ph", 0);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(24));
        scroll.addView(root);

        root.addView(text("Ekran Daraltıcı", 24));
        status = text("", 15);
        root.addView(status);

        Button openShizuku = button("Shizuku'yu aç");
        openShizuku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i == null) {
                    toast("Shizuku yüklü değil");
                } else {
                    startActivity(i);
                }
            }
        });
        root.addView(openShizuku);

        Button perm = button("Shizuku iznini ver");
        perm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Sh.alive()) {
                    toast("Önce Shizuku'yu aç ve başlat");
                    return;
                }
                try {
                    Shizuku.requestPermission(100);
                } catch (Throwable t) {
                    toast("İzin istenemedi: " + t);
                }
            }
        });
        root.addView(perm);

        info = text("", 15);
        root.addView(info);

        wTxt = text("", 15);
        root.addView(wTxt);
        sw = new SeekBar(this);
        sw.setMax(40);
        sw.setProgress(40);
        root.addView(sw);

        hTxt = text("", 15);
        root.addView(hTxt);
        sh = new SeekBar(this);
        sh.setMax(40);
        sh.setProgress(20);
        root.addView(sh);

        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                updateTexts();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        };
        sw.setOnSeekBarChangeListener(l);
        sh.setOnSeekBarChangeListener(l);

        Button test = button("Sadece uygula (test)");
        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doApply(null);
            }
        });
        root.addView(test);

        Button reset = button("SIFIRLA (eski ekran)");
        reset.setBackgroundColor(Color.parseColor("#C62828"));
        reset.setTextColor(Color.WHITE);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ex.execute(new Runnable() {
                    @Override
                    public void run() {
                        final String err = Ops.reset(getApplicationContext());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                toast(err != null ? err : "Sıfırlandı");
                            }
                        });
                    }
                });
            }
        });
        root.addView(reset);

        root.addView(text("Oyunlar (dokun: daralt ve aç, basılı tut: sil)", 16));
        gamesBox = new LinearLayout(this);
        gamesBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(gamesBox);

        Button add = button("Oyun ekle");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addGame();
            }
        });
        root.addView(add);

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        loadGames();
        updateTexts();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        if (Sh.ready()) readPhysical();
    }

    private void toast(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
    }

    private void refreshStatus() {
        if (!Sh.alive()) {
            status.setText("Shizuku: çalışmıyor. Shizuku'yu aç ve başlat.");
        } else if (!Sh.ready()) {
            status.setText("Shizuku: çalışıyor, izin verilmedi.");
        } else {
            status.setText("Shizuku: hazır ✔");
        }
    }

    private void readPhysical() {
        ex.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Sh.Result r = Sh.run("wm size");
                    Matcher m = Pattern.compile("Physical size: (\\d+)x(\\d+)").matcher(r.out);
                    if (m.find()) {
                        final int w = Integer.parseInt(m.group(1));
                        final int h = Integer.parseInt(m.group(2));
                        p.edit().putInt("pw", w).putInt("ph", h).apply();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                pw = w;
                                ph = h;
                                updateTexts();
                            }
                        });
                    }
                } catch (Throwable ignored) {
                }
            }
        });
    }

    private int even(double v) {
        int i = (int) Math.round(v);
        return i - (i % 2);
    }

    private int targetW() {
        return even(pw * (60 + sw.getProgress()) / 100.0);
    }

    private int targetH() {
        return even(ph * (60 + sh.getProgress()) / 100.0);
    }

    private void updateTexts() {
        if (pw == 0) {
            info.setText("Ekranın gerçek boyutu henüz okunmadı (Shizuku hazır olunca okunur).");
            wTxt.setText("Genişlik: %" + (60 + sw.getProgress()));
            hTxt.setText("Yükseklik: %" + (60 + sh.getProgress()));
            return;
        }
        info.setText("Ekranın gerçek boyutu: " + pw + "x" + ph);
        wTxt.setText("Genişlik: %" + (60 + sw.getProgress()) + " → " + targetW());
        hTxt.setText("Yükseklik: %" + (60 + sh.getProgress()) + " → " + targetH());
    }

    private void doApply(final String pkg) {
        if (!Sh.ready()) {
            toast("Önce Shizuku'yu başlat ve izin ver");
            return;
        }
        if (pw == 0) {
            toast("Ekran boyutu henüz okunmadı");
            return;
        }
        final int tw = targetW();
        final int th = targetH();
        // Ek guvenlik: gercek boyutun %60'indan kucuk ya da buyuk olamaz
        if (tw < pw * 0.6 - 1 || th < ph * 0.6 - 1 || tw > pw || th > ph) {
            toast("Bu boyut güvenli aralığın dışında");
            return;
        }
        ex.execute(new Runnable() {
            @Override
            public void run() {
                final String err = Ops.apply(getApplicationContext(), tw, th);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (err != null) {
                            toast(err);
                            return;
                        }
                        toast("Uygulandı. " + Ops.SECONDS + " sn içinde bildirimden KALSIN'a bas");
                        if (pkg != null) {
                            Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
                            if (li != null) startActivity(li);
                        }
                    }
                });
            }
        });
    }

    private Set<String> games() {
        return new HashSet<String>(p.getStringSet("games", new HashSet<String>()));
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private void loadGames() {
        gamesBox.removeAllViews();
        for (final String pkg : games()) {
            Button b = button(labelOf(pkg));
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    doApply(pkg);
                }
            });
            b.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setMessage(labelOf(pkg) + " listeden silinsin mi?")
                            .setPositiveButton("Sil", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int w) {
                                    Set<String> s = games();
                                    s.remove(pkg);
                                    p.edit().putStringSet("games", s).apply();
                                    loadGames();
                                }
                            })
                            .setNegativeButton("Vazgeç", null)
                            .show();
                    return true;
                }
            });
            gamesBox.addView(b);
        }
    }

    private void addGame() {
        final PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(q, 0);
        final List<String> pkgs = new ArrayList<String>();
        final List<String> names = new ArrayList<String>();
        Collections.sort(found, new Comparator<ResolveInfo>() {
            @Override
            public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        for (ResolveInfo ri : found) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || pkgs.contains(pkg)) continue;
            pkgs.add(pkg);
            names.add(ri.loadLabel(pm).toString());
        }
        new AlertDialog.Builder(this)
                .setTitle("Oyun seç")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Set<String> s = games();
                        s.add(pkgs.get(which));
                        p.edit().putStringSet("games", s).apply();
                        loadGames();
                    }
                })
                .show();
    }
}
